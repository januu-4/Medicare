#!/usr/bin/env python3
"""
OCR Service Startup Script
"""
import os
import uvicorn

if __name__ == "__main__":
    port = int(os.getenv("OCR_PORT", 8001))
    host = os.getenv("OCR_HOST", "0.0.0.0")
    
    print(f"Starting OCR service on {host}:{port}")
    
    uvicorn.run(
        "main:app", 
        host=host, 
        port=port, 
        reload=True,
        log_level="info"
    )