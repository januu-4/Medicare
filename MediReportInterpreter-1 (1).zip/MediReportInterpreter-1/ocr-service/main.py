#!/usr/bin/env python3
"""
Python OCR Microservice using FastAPI and pytesseract
Handles OCR processing for prescription images with multiple language support
"""

import os
import io
import logging
import asyncio
from typing import Optional, Dict, Any, List
import cv2
import numpy as np
import pytesseract
from PIL import Image, ImageEnhance, ImageFilter
from fastapi import FastAPI, File, UploadFile, HTTPException, Header, Form
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(title="OCR Microservice", version="1.0.0")

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Shared secret for authentication between services
SHARED_SECRET = os.getenv("OCR_SHARED_SECRET", "dev-secret-123")

# Supported languages with their Tesseract codes
SUPPORTED_LANGUAGES = {
    'eng': 'English',
    'spa': 'Spanish', 
    'fra': 'French',
    'deu': 'German',
    'ita': 'Italian',
    'por': 'Portuguese',
    'rus': 'Russian',
    'chi_sim': 'Chinese (Simplified)',
    'chi_tra': 'Chinese (Traditional)',
    'jpn': 'Japanese',
    'kor': 'Korean',
    'ara': 'Arabic',
    'hin': 'Hindi',
    'nld': 'Dutch',
    'pol': 'Polish',
    'tur': 'Turkish'
}

def authenticate_request(authorization: str = Header(None)):
    """Validate shared secret authentication"""
    if authorization != f"Bearer {SHARED_SECRET}":
        raise HTTPException(status_code=401, detail="Invalid authentication")

def preprocess_image(image_bytes: bytes) -> np.ndarray:
    """
    Preprocess image for better OCR accuracy
    - Convert to grayscale
    - Apply noise reduction
    - Enhance contrast
    - Apply adaptive thresholding
    """
    try:
        # Convert bytes to PIL Image
        pil_image = Image.open(io.BytesIO(image_bytes))
        
        # Convert to RGB if necessary
        if pil_image.mode != 'RGB':
            pil_image = pil_image.convert('RGB')
        
        # Convert PIL to OpenCV format
        cv_image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        
        # Convert to grayscale
        gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
        
        # Apply noise reduction
        denoised = cv2.medianBlur(gray, 3)
        
        # Apply adaptive threshold to get sharp image suitable for OCR
        processed = cv2.adaptiveThreshold(
            denoised, 
            255, 
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY, 
            11, 
            2
        )
        
        return processed
        
    except Exception as e:
        logger.error(f"Image preprocessing error: {e}")
        # Fallback: return original image as grayscale
        pil_image = Image.open(io.BytesIO(image_bytes))
        if pil_image.mode != 'RGB':
            pil_image = pil_image.convert('RGB')
        cv_image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        return cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

def enhance_image_quality(image: np.ndarray) -> np.ndarray:
    """Apply additional enhancements for medical document OCR"""
    # Convert to PIL for enhancement operations
    pil_image = Image.fromarray(image)
    
    # Enhance contrast
    enhancer = ImageEnhance.Contrast(pil_image)
    enhanced = enhancer.enhance(1.5)
    
    # Enhance sharpness
    enhancer = ImageEnhance.Sharpness(enhanced)
    enhanced = enhancer.enhance(2.0)
    
    # Apply slight blur to smooth edges
    enhanced = enhanced.filter(ImageFilter.SMOOTH_MORE)
    
    return np.array(enhanced)

async def perform_ocr_with_retry(
    image: np.ndarray, 
    language: str = 'eng', 
    retries: int = 3
) -> Dict[str, Any]:
    """Perform OCR with retry logic and confidence scoring"""
    
    best_result = {"text": "", "confidence": 0.0, "language_detected": language}
    
    for attempt in range(retries):
        try:
            logger.info(f"OCR attempt {attempt + 1} for language: {language}")
            
            # Configure Tesseract
            custom_config = r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,()/-: '
            
            # Get OCR data with confidence scores
            data = pytesseract.image_to_data(
                image, 
                lang=language,
                config=custom_config,
                output_type=pytesseract.Output.DICT
            )
            
            # Extract text and calculate confidence
            words = []
            confidences = []
            
            for i in range(len(data['text'])):
                word = data['text'][i].strip()
                conf = int(data['conf'][i])
                
                if word and conf > 0:  # Only include confident words
                    words.append(word)
                    confidences.append(conf)
            
            extracted_text = ' '.join(words)
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            
            # Update best result if this attempt is better
            if avg_confidence > best_result["confidence"] and len(extracted_text.strip()) > 5:
                best_result = {
                    "text": extracted_text.strip(),
                    "confidence": round(avg_confidence / 100, 2),  # Convert to 0-1 scale
                    "language_detected": language,
                    "word_count": len(words),
                    "processing_attempt": attempt + 1
                }
            
            # If we got good results, break early
            if avg_confidence > 70 and len(extracted_text.strip()) > 10:
                break
                
        except Exception as e:
            logger.error(f"OCR attempt {attempt + 1} failed: {e}")
            continue
    
    return best_result

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "ocr-microservice"}

@app.get("/languages")
async def get_supported_languages():
    """Get list of supported languages"""
    return {"supported_languages": SUPPORTED_LANGUAGES}

@app.post("/ocr")
async def extract_text(
    file: UploadFile = File(...),
    language: str = Form('eng'),
    enhance: bool = Form(True),
    authorization: str = Header(None)
):
    """
    Extract text from uploaded image using OCR
    
    Args:
        file: Image file (JPG, PNG, PDF)
        language: Language code for OCR (default: 'eng')
        enhance: Whether to apply image enhancements (default: True)
        authorization: Bearer token for authentication
    
    Returns:
        JSON with extracted text, confidence score, and metadata
    """
    
    # Authenticate request
    authenticate_request(authorization)
    
    # Validate language
    if language not in SUPPORTED_LANGUAGES:
        raise HTTPException(
            status_code=400, 
            detail=f"Unsupported language: {language}. Supported: {list(SUPPORTED_LANGUAGES.keys())}"
        )
    
    # Validate file type
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    try:
        # Read file content
        file_content = await file.read()
        
        if len(file_content) == 0:
            raise HTTPException(status_code=400, detail="Empty file")
        
        logger.info(f"Processing {file.filename} ({len(file_content)} bytes) in language: {language}")
        
        # Preprocess image
        processed_image = preprocess_image(file_content)
        
        # Apply additional enhancements if requested
        if enhance:
            processed_image = enhance_image_quality(processed_image)
        
        # Perform OCR with retry logic
        ocr_result = await perform_ocr_with_retry(processed_image, language)
        
        # Log results
        logger.info(f"OCR completed: {len(ocr_result['text'])} chars, confidence: {ocr_result['confidence']}")
        
        if len(ocr_result['text'].strip()) < 5:
            logger.warning("OCR extracted very little text")
        
        return {
            "success": True,
            "filename": file.filename,
            "text": ocr_result['text'],
            "confidence": ocr_result['confidence'],
            "language": language,
            "language_name": SUPPORTED_LANGUAGES[language],
            "word_count": ocr_result.get('word_count', 0),
            "processing_metadata": {
                "file_size": len(file_content),
                "enhancement_applied": enhance,
                "processing_attempt": ocr_result.get('processing_attempt', 1)
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OCR processing error: {e}")
        raise HTTPException(status_code=500, detail=f"OCR processing failed: {str(e)}")

@app.post("/batch-ocr")
async def batch_extract_text(
    files: List[UploadFile] = File(...),
    language: str = Form('eng'),
    enhance: bool = Form(True),
    authorization: str = Header(None)
):
    """
    Extract text from multiple images in batch
    Limited to 5 files to prevent resource exhaustion
    """
    
    # Authenticate request
    authenticate_request(authorization)
    
    if len(files) > 5:
        raise HTTPException(status_code=400, detail="Maximum 5 files allowed per batch")
    
    results = []
    
    for file in files:
        try:
            # Process each file individually
            result = await extract_text(file, language, enhance, authorization)
            results.append(result)
        except Exception as e:
            logger.error(f"Batch OCR error for {file.filename}: {e}")
            results.append({
                "success": False,
                "filename": file.filename,
                "error": str(e)
            })
    
    return {"batch_results": results}

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8001))
    uvicorn.run(app, host="0.0.0.0", port=port)