// Firebase Admin SDK configuration for server-side operations
import { initializeApp, getApps, cert } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { getStorage } from "firebase-admin/storage";
import { getAuth } from "firebase-admin/auth";

let app;
let db;
let storage;
let auth;

// Initialize Firebase Admin if not already initialized
if (!getApps().length) {
  // For server-side, we would normally use a service account
  // But for development, we'll use the same config as client
  // In production, you should use proper service account credentials
  app = initializeApp({
    projectId: process.env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: `${process.env.VITE_FIREBASE_PROJECT_ID}.firebasestorage.app`,
    // serviceAccount: JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '{}'),
  });
  
  db = getFirestore(app);
  storage = getStorage(app);
  auth = getAuth(app);
} else {
  app = getApps()[0];
  db = getFirestore(app);
  storage = getStorage(app);
  auth = getAuth(app);
}

export { db, storage, auth };
export default app;