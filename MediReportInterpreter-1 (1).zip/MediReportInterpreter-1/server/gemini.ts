// Gemini AI integration for document analysis
// Based on javascript_gemini blueprint
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

// Extract clinical values with abnormal result detection
export async function extractClinicalValues(text: string): Promise<any> {
  const prompt = `
Analyze the following medical report text and extract numeric clinical values with abnormal result detection.
Return a JSON object with the following structure:
{
  "clinicalValues": {
    "bloodSugar": {
      "value": "120 mg/dL",
      "status": "normal|high|low|critical_high|critical_low",
      "normalRange": "70-99 mg/dL (fasting)"
    },
    "bloodPressure": {
      "value": "140/90 mmHg",
      "status": "normal|high|low|critical_high|critical_low",
      "normalRange": "<120/80 mmHg"
    },
    "cholesterol": {
      "value": "200 mg/dL",
      "status": "normal|high|low|critical_high|critical_low",
      "normalRange": "<200 mg/dL"
    },
    "hemoglobin": {
      "value": "14.5 g/dL",
      "status": "normal|high|low|critical_high|critical_low",
      "normalRange": "12-16 g/dL (varies by gender)"
    },
    "whiteBloodCell": {
      "value": "7500 cells/µL",
      "status": "normal|high|low|critical_high|critical_low",
      "normalRange": "4,500-11,000 cells/µL"
    },
    "platelets": {
      "value": "250,000 cells/µL",
      "status": "normal|high|low|critical_high|critical_low",
      "normalRange": "150,000-400,000 cells/µL"
    }
  },
  "abnormalResults": [
    {
      "parameter": "name of abnormal parameter",
      "value": "actual value",
      "status": "high|low|critical_high|critical_low",
      "severity": "mild|moderate|severe",
      "explanation": "Simple explanation of what this abnormal result means"
    }
  ],
  "findings": ["list of key findings from the report"],
  "overallSeverity": "normal|mild|moderate|severe|critical",
  "riskLevel": "low|moderate|high|critical"
}

Classify each value as:
- normal: Within normal range
- high/low: Outside normal range but not dangerous
- critical_high/critical_low: Dangerously high or low values requiring immediate attention

Only include values that are actually present in the text. If a value is not found, omit it from the response.

Medical Report Text:
${text}
`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            clinicalValues: {
              type: "object",
              properties: {
                bloodSugar: {
                  type: "object",
                  properties: {
                    value: { type: "string" },
                    status: { type: "string", enum: ["normal", "high", "low", "critical_high", "critical_low"] },
                    normalRange: { type: "string" }
                  }
                },
                bloodPressure: {
                  type: "object",
                  properties: {
                    value: { type: "string" },
                    status: { type: "string", enum: ["normal", "high", "low", "critical_high", "critical_low"] },
                    normalRange: { type: "string" }
                  }
                },
                cholesterol: {
                  type: "object",
                  properties: {
                    value: { type: "string" },
                    status: { type: "string", enum: ["normal", "high", "low", "critical_high", "critical_low"] },
                    normalRange: { type: "string" }
                  }
                },
                hemoglobin: {
                  type: "object",
                  properties: {
                    value: { type: "string" },
                    status: { type: "string", enum: ["normal", "high", "low", "critical_high", "critical_low"] },
                    normalRange: { type: "string" }
                  }
                },
                whiteBloodCell: {
                  type: "object",
                  properties: {
                    value: { type: "string" },
                    status: { type: "string", enum: ["normal", "high", "low", "critical_high", "critical_low"] },
                    normalRange: { type: "string" }
                  }
                },
                platelets: {
                  type: "object",
                  properties: {
                    value: { type: "string" },
                    status: { type: "string", enum: ["normal", "high", "low", "critical_high", "critical_low"] },
                    normalRange: { type: "string" }
                  }
                }
              }
            },
            abnormalResults: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  parameter: { type: "string" },
                  value: { type: "string" },
                  status: { type: "string", enum: ["high", "low", "critical_high", "critical_low"] },
                  severity: { type: "string", enum: ["mild", "moderate", "severe"] },
                  explanation: { type: "string" }
                },
                required: ["parameter", "value", "status", "severity", "explanation"]
              }
            },
            findings: {
              type: "array",
              items: { type: "string" }
            },
            overallSeverity: {
              type: "string",
              enum: ["normal", "mild", "moderate", "severe", "critical"]
            },
            riskLevel: {
              type: "string",
              enum: ["low", "moderate", "high", "critical"]
            }
          },
          required: ["clinicalValues", "abnormalResults", "findings", "overallSeverity", "riskLevel"]
        }
      },
      contents: prompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson);
    } else {
      throw new Error("Empty response from Gemini");
    }
  } catch (error) {
    console.error("Error extracting clinical values:", error);
    throw error;
  }
}

// Explain medical results with focus on abnormal findings
export async function explainResults(text: string, clinicalValues: any, abnormalResults: any): Promise<any> {
  const prompt = `
You are a medical assistant helping patients understand their test results with special focus on abnormal findings.
Analyze the following medical report, clinical values, and abnormal results, then provide clear explanations.

Return a JSON object with this structure:
{
  "explanation": "Simple, patient-friendly explanation focusing on abnormal results",
  "summary": "Brief summary of overall health status with emphasis on concerns",
  "abnormalExplanations": [
    {
      "parameter": "name of abnormal parameter",
      "simpleExplanation": "What this means in simple terms",
      "possibleCauses": ["list of possible causes"],
      "urgency": "immediate|soon|routine",
      "actionNeeded": "What the patient should do"
    }
  ],
  "recommendations": ["prioritized list of recommendations, urgent ones first"],
  "normalRanges": {
    "explanation": "Brief explanation of what normal ranges mean"
  },
  "nextSteps": "Clear guidance on what the patient should do next"
}

Medical Report:
${text}

Extracted Clinical Values:
${JSON.stringify(clinicalValues, null, 2)}

Abnormal Results:
${JSON.stringify(abnormalResults, null, 2)}
`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            explanation: { type: "string" },
            summary: { type: "string" },
            abnormalExplanations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  parameter: { type: "string" },
                  simpleExplanation: { type: "string" },
                  possibleCauses: {
                    type: "array",
                    items: { type: "string" }
                  },
                  urgency: { type: "string", enum: ["immediate", "soon", "routine"] },
                  actionNeeded: { type: "string" }
                },
                required: ["parameter", "simpleExplanation", "possibleCauses", "urgency", "actionNeeded"]
              }
            },
            recommendations: {
              type: "array",
              items: { type: "string" }
            },
            normalRanges: {
              type: "object",
              properties: {
                explanation: { type: "string" }
              }
            },
            nextSteps: { type: "string" }
          },
          required: ["explanation", "summary", "abnormalExplanations", "recommendations", "normalRanges", "nextSteps"]
        }
      },
      contents: prompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson);
    } else {
      throw new Error("Empty response from Gemini");
    }
  } catch (error) {
    console.error("Error explaining results:", error);
    throw error;
  }
}

// Generate medication schedule from prescription text
export async function generateMedicationSchedule(text: string): Promise<any> {
  const prompt = `
Analyze the following prescription text and extract medication information.
Generate a medication schedule with dosage times.

Return a JSON object with this structure:
{
  "prescriptions": [
    {
      "medicationName": "name of medication",
      "dosage": "dosage amount (e.g., '500mg')",
      "frequency": "how often (e.g., 'twice daily')",
      "duration": "how long (e.g., '7 days')",
      "instructions": "special instructions",
      "schedule": [
        {"time": "08:00", "dosage": "500mg"},
        {"time": "20:00", "dosage": "500mg"}
      ]
    }
  ]
}

Prescription Text:
${text}
`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            prescriptions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  medicationName: { type: "string" },
                  dosage: { type: "string" },
                  frequency: { type: "string" },
                  duration: { type: "string" },
                  instructions: { type: "string" },
                  schedule: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        time: { type: "string" },
                        dosage: { type: "string" }
                      },
                      required: ["time", "dosage"]
                    }
                  }
                },
                required: ["medicationName", "dosage", "frequency", "duration", "schedule"]
              }
            }
          },
          required: ["prescriptions"]
        }
      },
      contents: prompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson);
    } else {
      throw new Error("Empty response from Gemini");
    }
  } catch (error) {
    console.error("Error generating medication schedule:", error);
    throw error;
  }
}

// Summarize medical report
export async function summarizeReport(text: string): Promise<string> {
  const prompt = `
Summarize the following medical report in simple, patient-friendly language.
Focus on the key findings and what they mean for the patient.
Keep it concise but informative.

Medical Report:
${text}
`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || "Unable to generate summary";
  } catch (error) {
    console.error("Error summarizing report:", error);
    throw error;
  }
}