// Authentication middleware for Firebase ID token validation
import { Request, Response, NextFunction } from 'express';
import * as admin from 'firebase-admin';
import '../firebase-admin'; // Ensure Firebase Admin is initialized

export interface AuthRequest extends Request {
  user?: {
    uid: string;
    email?: string;
  };
}

export const authenticateUser = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Authorization header with Bearer token required' });
    }

    const idToken = authHeader.split('Bearer ')[1];
    
    if (!idToken) {
      return res.status(401).json({ error: 'ID token required' });
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
    };
    
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
};

export const validateUserAccess = (req: AuthRequest, res: Response, next: NextFunction) => {
  const requestedUserId = req.params.userId || req.body.userId;
  
  if (!req.user) {
    return res.status(401).json({ error: 'User not authenticated' });
  }
  
  if (requestedUserId && requestedUserId !== req.user.uid) {
    return res.status(403).json({ error: 'Access denied: Cannot access other user\'s data' });
  }
  
  next();
};