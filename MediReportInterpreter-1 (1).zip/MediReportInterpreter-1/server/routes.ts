import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { extractClinicalValues, explainResults, generateMedicationSchedule, summarizeReport } from "./gemini";
import { authenticateUser, validateUserAccess, type AuthRequest } from "./middleware/auth";
import { registerPrescriptionRoutes } from "./prescription-analyzer";
// Firebase storage operations would be handled via admin SDK in production
// For now, we'll simulate file storage
// OCR libraries would be imported here
// import * as vision from "@google-cloud/vision";
// import Tesseract from "tesseract.js";
import { z } from "zod";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

// Validation schemas
const processReportSchema = z.object({
  fileName: z.string(),
  fileType: z.string(),
  ocrText: z.string(),
  ocrConfidence: z.number().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Register prescription analyzer routes
  registerPrescriptionRoutes(app);
  
  // Google Cloud Vision OCR fallback endpoint
  app.post("/api/vision", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      // Simulate OCR processing
      // In production, this would use Google Cloud Vision API
      const text = "Sample extracted text from medical report";
      
      res.json({
        text: text || "",
        confidence: 0.9,
      });

    } catch (error) {
      console.error("Vision API error:", error);
      res.status(500).json({ error: "OCR processing failed" });
    }
  });

  // Gemini LLM processing endpoint
  app.post("/api/llm", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const { text, task } = req.body;
      
      if (!text || !task) {
        return res.status(400).json({ error: "Text and task are required" });
      }

      let result;
      
      switch (task) {
        case "extract":
          result = await extractClinicalValues(text);
          break;
        case "explain":
          result = await explainResults(text, req.body.clinicalValues || {}, req.body.abnormalResults || []);
          break;
        case "schedule":
          result = await generateMedicationSchedule(text);
          break;
        case "summarize":
          result = await summarizeReport(text);
          break;
        default:
          return res.status(400).json({ error: "Invalid task" });
      }

      res.json({ result });

    } catch (error) {
      console.error("LLM processing error:", error);
      res.status(500).json({ error: "AI processing failed" });
    }
  });

  // Process report endpoint - save AI analysis to Firestore
  app.post("/api/process-report", authenticateUser, upload.single("file"), async (req: AuthRequest, res) => {
    try {
      const { fileName, fileType } = req.body;
      const userId = req.user!.uid; // Get from authenticated user
      
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      // Simulate file upload to storage
      const downloadURL = `https://storage.example.com/reports/${userId}/${Date.now()}_${fileName}`;

      // Simulate OCR processing
      // In production, this would use Tesseract.js or Google Cloud Vision API
      let ocrText = "Sample extracted text from uploaded medical report. Contains various medical values and findings.";
      let ocrConfidence = 0.95;

      // Create initial report in Firestore
      const reportData = {
        userId,
        fileName,
        fileType,
        fileSize: req.file.size,
        storageUrl: downloadURL,
        ocrText,
        ocrConfidence,
        processingStatus: 'processing' as const,
      };

      const report = await storage.createReport(reportData);

      // Perform AI analysis if we have OCR text
      if (ocrText && ocrText.trim().length > 50) {
        try {
          // Extract clinical values with abnormal result detection
          const clinicalData = await extractClinicalValues(ocrText);
          
          // Get explanation with focus on abnormal results
          const explanation = await explainResults(ocrText, clinicalData.clinicalValues, clinicalData.abnormalResults);
          
          // Generate summary
          const summary = await summarizeReport(ocrText);

          // Update report with enhanced AI analysis
          const extractedData = {
            clinicalValues: clinicalData.clinicalValues,
            abnormalResults: clinicalData.abnormalResults,
            explanation: explanation.explanation,
            abnormalExplanations: explanation.abnormalExplanations,
            summary,
            overallSeverity: clinicalData.overallSeverity,
            riskLevel: clinicalData.riskLevel,
            findings: clinicalData.findings,
            recommendations: explanation.recommendations,
            nextSteps: explanation.nextSteps,
          };

          await storage.updateReport(report.id, {
            extractedData,
            processingStatus: 'completed',
          });

          // Add to health timeline if we have numeric values
          if (clinicalData.clinicalValues) {
            const metrics: any = {};
            
            // Extract numeric values for timeline from enhanced structure
            if (clinicalData.clinicalValues.bloodSugar?.value) {
              const match = clinicalData.clinicalValues.bloodSugar.value.match(/(\d+(?:\.\d+)?)/);
              if (match) metrics.bloodSugar = parseFloat(match[1]);
            }
            
            if (clinicalData.clinicalValues.bloodPressure?.value) {
              const match = clinicalData.clinicalValues.bloodPressure.value.match(/(\d+)\/(\d+)/);
              if (match) {
                metrics.systolicBP = parseInt(match[1]);
                metrics.diastolicBP = parseInt(match[2]);
              }
            }
            
            if (clinicalData.clinicalValues.cholesterol?.value) {
              const match = clinicalData.clinicalValues.cholesterol.value.match(/(\d+(?:\.\d+)?)/);
              if (match) metrics.cholesterol = parseFloat(match[1]);
            }
            
            if (clinicalData.clinicalValues.hemoglobin?.value) {
              const match = clinicalData.clinicalValues.hemoglobin.value.match(/(\d+(?:\.\d+)?)/);
              if (match) metrics.hemoglobin = parseFloat(match[1]);
            }

            if (Object.keys(metrics).length > 0) {
              await storage.addHealthTimeline({
                userId,
                reportId: report.id,
                date: new Date(),
                metrics,
              });
            }
          }

          res.json({ 
            reportId: report.id,
            extractedData,
            status: 'completed'
          });

        } catch (aiError) {
          console.error("AI analysis failed:", aiError);
          
          // Mark as completed but without analysis
          await storage.updateReport(report.id, {
            processingStatus: 'completed',
          });
          
          res.json({ 
            reportId: report.id,
            status: 'completed',
            note: 'Report uploaded but AI analysis failed'
          });
        }
      } else {
        // No sufficient OCR text, mark as completed
        await storage.updateReport(report.id, {
          processingStatus: 'completed',
        });
        
        res.json({ 
          reportId: report.id,
          status: 'completed',
          note: 'Report uploaded but no text could be extracted'
        });
      }

    } catch (error) {
      console.error("Report processing error:", error);
      res.status(500).json({ error: "Report processing failed" });
    }
  });

  // Get user reports
  app.get("/api/reports/:userId", authenticateUser, validateUserAccess, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid; // Use authenticated user's ID
      const reports = await storage.getUserReports(userId);
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });

  // Get user health timeline
  app.get("/api/health-timeline/:userId", authenticateUser, validateUserAccess, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid; // Use authenticated user's ID
      const timeline = await storage.getUserHealthTimeline(userId);
      res.json(timeline);
    } catch (error) {
      console.error("Error fetching health timeline:", error);
      res.status(500).json({ error: "Failed to fetch health timeline" });
    }
  });

  // Create reminder
  app.post("/api/reminders", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const reminderData = { ...req.body, userId: req.user!.uid }; // Ensure userId matches authenticated user
      const reminderId = await storage.createReminder(reminderData);
      res.json({ id: reminderId });
    } catch (error) {
      console.error("Error creating reminder:", error);
      res.status(500).json({ error: "Failed to create reminder" });
    }
  });

  // Get user reminders
  app.get("/api/reminders/:userId", authenticateUser, validateUserAccess, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid; // Use authenticated user's ID
      const reminders = await storage.getUserReminders(userId);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching reminders:", error);
      res.status(500).json({ error: "Failed to fetch reminders" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}