// In-memory storage interface for development
// In production, you would use Firebase Admin SDK or direct database connection
import { randomUUID } from "crypto";
import type { 
  User, 
  Report, 
  HealthTimeline,
  Reminder,
  InsertUser, 
  InsertReport,
  InsertHealthTimeline,
  InsertReminder
} from "@shared/schema";


export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<void>;
  
  // Report operations
  createReport(report: InsertReport): Promise<Report>;
  getReport(id: string): Promise<Report | undefined>;
  getUserReports(userId: string): Promise<Report[]>;
  updateReport(id: string, updates: Partial<Report>): Promise<void>;
  
  // Health timeline operations
  addHealthTimeline(timeline: InsertHealthTimeline): Promise<string>;
  getUserHealthTimeline(userId: string): Promise<HealthTimeline[]>;
  
  // Reminder operations
  createReminder(reminder: InsertReminder): Promise<string>;
  getUserReminders(userId: string): Promise<Reminder[]>;
  updateReminder(id: string, updates: Partial<Reminder>): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private reports: Map<string, Report> = new Map();
  private healthTimeline: Map<string, HealthTimeline> = new Map();
  private reminders: Map<string, Reminder> = new Map();
  
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<void> {
    const existingUser = this.users.get(id);
    if (existingUser) {
      this.users.set(id, {
        ...existingUser,
        ...updates,
        updatedAt: new Date(),
      });
    }
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = randomUUID();
    const report: Report = {
      ...insertReport,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.reports.set(id, report);
    return report;
  }

  async getReport(id: string): Promise<Report | undefined> {
    return this.reports.get(id);
  }

  async getUserReports(userId: string): Promise<Report[]> {
    return Array.from(this.reports.values())
      .filter(report => report.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async updateReport(id: string, updates: Partial<Report>): Promise<void> {
    const existingReport = this.reports.get(id);
    if (existingReport) {
      this.reports.set(id, {
        ...existingReport,
        ...updates,
        updatedAt: new Date(),
      });
    }
  }

  async addHealthTimeline(insertTimeline: InsertHealthTimeline): Promise<string> {
    const id = randomUUID();
    const timeline: HealthTimeline = {
      ...insertTimeline,
      id,
    };
    this.healthTimeline.set(id, timeline);
    return id;
  }

  async getUserHealthTimeline(userId: string): Promise<HealthTimeline[]> {
    return Array.from(this.healthTimeline.values())
      .filter(timeline => timeline.userId === userId)
      .sort((a, b) => b.date.getTime() - a.date.getTime());
  }

  async createReminder(insertReminder: InsertReminder): Promise<string> {
    const id = randomUUID();
    const reminder: Reminder = {
      ...insertReminder,
      id,
      createdAt: new Date(),
    };
    this.reminders.set(id, reminder);
    return id;
  }

  async getUserReminders(userId: string): Promise<Reminder[]> {
    return Array.from(this.reminders.values())
      .filter(reminder => reminder.userId === userId && !reminder.isCompleted)
      .sort((a, b) => a.scheduledTime.getTime() - b.scheduledTime.getTime());
  }

  async updateReminder(id: string, updates: Partial<Reminder>): Promise<void> {
    const existingReminder = this.reminders.get(id);
    if (existingReminder) {
      this.reminders.set(id, {
        ...existingReminder,
        ...updates,
      });
    }
  }
}

export const storage = new MemStorage();