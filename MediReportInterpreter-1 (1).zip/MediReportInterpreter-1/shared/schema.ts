// Firebase-based data models for MediReportInterpreter
import { z } from "zod";

// User profile data
export const userSchema = z.object({
  id: z.string(),
  email: z.string().email(),
  displayName: z.string().optional(),
  photoURL: z.string().optional(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

// Medical reports collection
export const reportSchema = z.object({
  id: z.string(),
  userId: z.string(),
  fileName: z.string(),
  fileType: z.string(),
  fileSize: z.number(),
  storageUrl: z.string(),
  ocrText: z.string().optional(),
  ocrConfidence: z.number().optional(),
  extractedData: z.object({
    clinicalValues: z.object({
      bloodSugar: z.string().optional(),
      bloodPressure: z.string().optional(),
      cholesterol: z.string().optional(),
      hemoglobin: z.string().optional(),
      whiteBloodCell: z.string().optional(),
      platelets: z.string().optional(),
    }).optional(),
    explanation: z.string().optional(),
    summary: z.string().optional(),
    riskLevel: z.enum(['low', 'moderate', 'high']).optional(),
    findings: z.array(z.string()).optional(),
  }).optional(),
  processingStatus: z.enum(['uploaded', 'processing', 'completed', 'error']),
  createdAt: z.date(),
  updatedAt: z.date(),
});

// Health timeline for tracking values over time
export const healthTimelineSchema = z.object({
  id: z.string(),
  userId: z.string(),
  reportId: z.string(),
  date: z.date(),
  metrics: z.object({
    bloodSugar: z.number().optional(),
    systolicBP: z.number().optional(),
    diastolicBP: z.number().optional(),
    cholesterol: z.number().optional(),
    hemoglobin: z.number().optional(),
    weight: z.number().optional(),
  }),
  notes: z.string().optional(),
});

// Reminders for medications and tests
export const reminderSchema = z.object({
  id: z.string(),
  userId: z.string(),
  type: z.enum(['medication', 'test', 'appointment']),
  title: z.string(),
  description: z.string().optional(),
  scheduledTime: z.date(),
  isCompleted: z.boolean().default(false),
  recurrence: z.enum(['once', 'daily', 'weekly', 'monthly']).optional(),
  createdAt: z.date(),
});

// Prescriptions with medication schedules
export const prescriptionSchema = z.object({
  id: z.string(),
  userId: z.string(),
  reportId: z.string().optional(),
  medicationName: z.string(),
  dosage: z.string(),
  frequency: z.string(),
  duration: z.string(),
  instructions: z.string().optional(),
  schedule: z.array(z.object({
    time: z.string(), // "08:00", "12:00", etc.
    dosage: z.string(),
  })),
  isActive: z.boolean().default(true),
  createdAt: z.date(),
});

// Chat rooms for doctor-patient communication
export const chatRoomSchema = z.object({
  id: z.string(),
  patientId: z.string(),
  doctorId: z.string(),
  patientName: z.string(),
  doctorName: z.string(),
  lastMessage: z.string().optional(),
  lastMessageTime: z.date().optional(),
  isActive: z.boolean().default(true),
  createdAt: z.date(),
});

// Chat messages
export const chatMessageSchema = z.object({
  id: z.string(),
  chatRoomId: z.string(),
  senderId: z.string(),
  senderName: z.string(),
  message: z.string(),
  timestamp: z.date(),
  attachments: z.array(z.object({
    fileName: z.string(),
    fileUrl: z.string(),
    fileType: z.string(),
  })).optional(),
});

// Export types
export type User = z.infer<typeof userSchema>;
export type Report = z.infer<typeof reportSchema>;
export type HealthTimeline = z.infer<typeof healthTimelineSchema>;
export type Reminder = z.infer<typeof reminderSchema>;
export type Prescription = z.infer<typeof prescriptionSchema>;
export type ChatRoom = z.infer<typeof chatRoomSchema>;
export type ChatMessage = z.infer<typeof chatMessageSchema>;

// Insert schemas (for creating new records)
export const insertUserSchema = userSchema.omit({ id: true, createdAt: true, updatedAt: true });
export const insertReportSchema = reportSchema.omit({ id: true, createdAt: true, updatedAt: true });
export const insertHealthTimelineSchema = healthTimelineSchema.omit({ id: true });
export const insertReminderSchema = reminderSchema.omit({ id: true, createdAt: true });
export const insertPrescriptionSchema = prescriptionSchema.omit({ id: true, createdAt: true });
export const insertChatRoomSchema = chatRoomSchema.omit({ id: true, createdAt: true });
export const insertChatMessageSchema = chatMessageSchema.omit({ id: true });

// Insert types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertReport = z.infer<typeof insertReportSchema>;
export type InsertHealthTimeline = z.infer<typeof insertHealthTimelineSchema>;
export type InsertReminder = z.infer<typeof insertReminderSchema>;
export type InsertPrescription = z.infer<typeof insertPrescriptionSchema>;
export type InsertChatRoom = z.infer<typeof insertChatRoomSchema>;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;