// Firebase Authentication utilities
// Based on firebase_barebones_javascript blueprint
import { 
  signInWithRedirect, 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  getRedirectResult,
  GoogleAuthProvider,
  onAuthStateChanged,
  User as FirebaseUser
} from "firebase/auth";
import { auth, googleProvider } from "./firebase";
import { createUser, getUser } from "./firestore";
import type { User, InsertUser } from "@shared/schema";

// Sign in with Google
export const signInWithGoogle = async (): Promise<void> => {
  try {
    await signInWithRedirect(auth, googleProvider);
  } catch (error) {
    console.error("Error signing in with Google:", error);
    throw error;
  }
};

// Handle redirect result from Google sign-in
export const handleRedirectResult = async (): Promise<User | null> => {
  try {
    const result = await getRedirectResult(auth);
    if (result && result.user) {
      // Create or update user in Firestore
      const firebaseUser = result.user;
      const userData: InsertUser = {
        email: firebaseUser.email!,
        displayName: firebaseUser.displayName || undefined,
        photoURL: firebaseUser.photoURL || undefined,
      };
      
      // Check if user exists, if not create them
      let user = await getUser(firebaseUser.uid);
      if (!user) {
        await createUser(firebaseUser.uid, userData);
        user = await getUser(firebaseUser.uid);
      }
      
      return user;
    }
    return null;
  } catch (error) {
    console.error("Error handling redirect result:", error);
    throw error;
  }
};

// Sign in with email and password
export const signInWithEmail = async (email: string, password: string): Promise<User | null> => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const firebaseUser = userCredential.user;
    
    // Get user from Firestore
    let user = await getUser(firebaseUser.uid);
    
    // If user doesn't exist in Firestore, create them
    if (!user) {
      const userData: InsertUser = {
        email: firebaseUser.email!,
        displayName: firebaseUser.displayName || undefined,
        photoURL: firebaseUser.photoURL || undefined,
      };
      await createUser(firebaseUser.uid, userData);
      user = await getUser(firebaseUser.uid);
    }
    
    return user;
  } catch (error) {
    console.error("Error signing in with email:", error);
    throw error;
  }
};

// Sign up with email and password
export const signUpWithEmail = async (email: string, password: string, displayName?: string): Promise<User | null> => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const firebaseUser = userCredential.user;
    
    // Create user in Firestore with the Firebase UID
    const userData: InsertUser = {
      email: firebaseUser.email!,
      displayName: displayName || undefined,
    };
    
    await createUser(firebaseUser.uid, userData);
    const user = await getUser(firebaseUser.uid);
    return user;
  } catch (error) {
    console.error("Error signing up with email:", error);
    throw error;
  }
};

// Sign out
export const signOutUser = async (): Promise<void> => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Error signing out:", error);
    throw error;
  }
};

// Auth state observer
export const onAuthStateChange = (callback: (user: FirebaseUser | null) => void) => {
  return onAuthStateChanged(auth, callback);
};