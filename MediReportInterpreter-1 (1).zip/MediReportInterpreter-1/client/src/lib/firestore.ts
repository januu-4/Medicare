// Firestore database operations
import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";
import { db } from "./firebase";
import type {
  User,
  Report,
  HealthTimeline,
  Reminder,
  Prescription,
  ChatRoom,
  ChatMessage,
  InsertUser,
  InsertReport,
  InsertHealthTimeline,
  InsertReminder,
  InsertPrescription,
  InsertChatRoom,
  InsertChatMessage,
} from "@shared/schema";

import { setDoc } from "firebase/firestore";

// Helper function to convert Firestore timestamps to Date objects
const convertTimestamps = (data: any) => {
  const result = { ...data };
  Object.keys(result).forEach(key => {
    if (result[key] instanceof Timestamp) {
      result[key] = result[key].toDate();
    }
  });
  return result;
};

// User operations
export const createUser = async (userId: string, userData: InsertUser): Promise<string> => {
  const userRef = doc(db, "users", userId);
  await setDoc(userRef, {
    ...userData,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return userId;
};

export const getUser = async (userId: string): Promise<User | null> => {
  const docRef = doc(db, "users", userId);
  const docSnap = await getDoc(docRef);
  
  if (docSnap.exists()) {
    return convertTimestamps({ id: userId, ...docSnap.data() }) as User;
  }
  return null;
};

export const updateUser = async (userId: string, updates: Partial<User>): Promise<void> => {
  const docRef = doc(db, "users", userId);
  await updateDoc(docRef, {
    ...updates,
    updatedAt: serverTimestamp(),
  });
};

// Report operations
export const createReport = async (reportData: InsertReport): Promise<string> => {
  const docRef = await addDoc(collection(db, "reports"), {
    ...reportData,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return docRef.id;
};

export const getUserReports = async (userId: string): Promise<Report[]> => {
  const q = query(
    collection(db, "reports"),
    where("userId", "==", userId),
    orderBy("createdAt", "desc")
  );
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => 
    convertTimestamps({ id: doc.id, ...doc.data() })
  ) as Report[];
};

export const updateReport = async (reportId: string, updates: Partial<Report>): Promise<void> => {
  const docRef = doc(db, "reports", reportId);
  await updateDoc(docRef, {
    ...updates,
    updatedAt: serverTimestamp(),
  });
};

export const getReport = async (reportId: string): Promise<Report | null> => {
  const docRef = doc(db, "reports", reportId);
  const docSnap = await getDoc(docRef);
  
  if (docSnap.exists()) {
    return convertTimestamps({ id: docSnap.id, ...docSnap.data() }) as Report;
  }
  return null;
};

// Health timeline operations
export const addHealthTimeline = async (timelineData: InsertHealthTimeline): Promise<string> => {
  const docRef = await addDoc(collection(db, "health_timeline"), timelineData);
  return docRef.id;
};

export const getUserHealthTimeline = async (userId: string): Promise<HealthTimeline[]> => {
  const q = query(
    collection(db, "health_timeline"),
    where("userId", "==", userId),
    orderBy("date", "desc")
  );
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => 
    convertTimestamps({ id: doc.id, ...doc.data() })
  ) as HealthTimeline[];
};

// Reminder operations
export const createReminder = async (reminderData: InsertReminder): Promise<string> => {
  const docRef = await addDoc(collection(db, "reminders"), {
    ...reminderData,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
};

export const getUserReminders = async (userId: string): Promise<Reminder[]> => {
  const q = query(
    collection(db, "reminders"),
    where("userId", "==", userId),
    where("isCompleted", "==", false),
    orderBy("scheduledTime", "asc")
  );
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => 
    convertTimestamps({ id: doc.id, ...doc.data() })
  ) as Reminder[];
};

export const updateReminder = async (reminderId: string, updates: Partial<Reminder>): Promise<void> => {
  const docRef = doc(db, "reminders", reminderId);
  await updateDoc(docRef, updates);
};

// Prescription operations
export const createPrescription = async (prescriptionData: InsertPrescription): Promise<string> => {
  const docRef = await addDoc(collection(db, "prescriptions"), {
    ...prescriptionData,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
};

export const getUserPrescriptions = async (userId: string): Promise<Prescription[]> => {
  const q = query(
    collection(db, "prescriptions"),
    where("userId", "==", userId),
    where("isActive", "==", true),
    orderBy("createdAt", "desc")
  );
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => 
    convertTimestamps({ id: doc.id, ...doc.data() })
  ) as Prescription[];
};

// Chat operations
export const createChatRoom = async (chatRoomData: InsertChatRoom): Promise<string> => {
  const docRef = await addDoc(collection(db, "chat_rooms"), {
    ...chatRoomData,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
};

export const sendMessage = async (messageData: InsertChatMessage): Promise<string> => {
  const docRef = await addDoc(collection(db, "chat_messages"), {
    ...messageData,
    timestamp: serverTimestamp(),
  });
  
  // Update last message in chat room
  const chatRoomRef = doc(db, "chat_rooms", messageData.chatRoomId);
  await updateDoc(chatRoomRef, {
    lastMessage: messageData.message,
    lastMessageTime: serverTimestamp(),
  });
  
  return docRef.id;
};

export const getChatMessages = (chatRoomId: string, callback: (messages: ChatMessage[]) => void) => {
  const q = query(
    collection(db, "chat_messages"),
    where("chatRoomId", "==", chatRoomId),
    orderBy("timestamp", "asc")
  );
  
  return onSnapshot(q, (querySnapshot) => {
    const messages = querySnapshot.docs.map(doc => 
      convertTimestamps({ id: doc.id, ...doc.data() })
    ) as ChatMessage[];
    callback(messages);
  });
};

export const getUserChatRooms = async (userId: string): Promise<ChatRoom[]> => {
  const q = query(
    collection(db, "chat_rooms"),
    where("patientId", "==", userId),
    orderBy("lastMessageTime", "desc")
  );
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => 
    convertTimestamps({ id: doc.id, ...doc.data() })
  ) as ChatRoom[];
};