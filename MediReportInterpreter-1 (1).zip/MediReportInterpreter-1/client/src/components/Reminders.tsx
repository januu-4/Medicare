import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Plus, 
  Pill, 
  Calendar, 
  Clock, 
  Bell, 
  Check, 
  X, 
  Edit,
  Trash2
} from "lucide-react";

interface Reminder {
  id: string;
  title: string;
  type: 'medication' | 'appointment' | 'test';
  time: string;
  frequency: 'once' | 'daily' | 'weekly' | 'monthly';
  dosage?: string;
  notes?: string;
  isActive: boolean;
  nextDue: Date;
  completed?: boolean;
}

interface RemindersProps {
  userId?: string;
}

export default function Reminders({ userId }: RemindersProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newReminder, setNewReminder] = useState({
    title: '',
    type: 'medication' as const,
    time: '',
    frequency: 'daily' as const,
    dosage: '',
    notes: ''
  });

  // todo: remove mock functionality - replace with real Firestore data
  const [reminders, setReminders] = useState<Reminder[]>([
    {
      id: '1',
      title: 'Metformin 500mg',
      type: 'medication',
      time: '08:00',
      frequency: 'daily',
      dosage: '500mg',
      notes: 'Take with breakfast',
      isActive: true,
      nextDue: new Date('2024-01-16T08:00:00'),
      completed: false
    },
    {
      id: '2',
      title: 'Blood Pressure Check',
      type: 'test',
      time: '19:00',
      frequency: 'daily',
      notes: 'Record systolic and diastolic values',
      isActive: true,
      nextDue: new Date('2024-01-16T19:00:00'),
      completed: true
    },
    {
      id: '3',
      title: 'Cardiology Appointment',
      type: 'appointment',
      time: '10:00',
      frequency: 'once',
      notes: 'Dr. Wilson - Follow-up consultation',
      isActive: true,
      nextDue: new Date('2024-01-17T10:00:00'),
      completed: false
    },
    {
      id: '4',
      title: 'Vitamin D Supplement',
      type: 'medication',
      time: '20:00',
      frequency: 'daily',
      dosage: '1000 IU',
      notes: 'Take with dinner',
      isActive: true,
      nextDue: new Date('2024-01-16T20:00:00'),
      completed: false
    },
    {
      id: '5',
      title: 'Weekly Weight Check',
      type: 'test',
      time: '07:00',
      frequency: 'weekly',
      notes: 'Record weight and BMI',
      isActive: true,
      nextDue: new Date('2024-01-21T07:00:00'),
      completed: false
    }
  ]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'medication':
        return <Pill className="h-4 w-4" />;
      case 'appointment':
        return <Calendar className="h-4 w-4" />;
      case 'test':
        return <Clock className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'medication':
        return 'default';
      case 'appointment':
        return 'secondary';
      case 'test':
        return 'outline';
      default:
        return 'default';
    }
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const formatNextDue = (date: Date) => {
    const now = new Date();
    const diffTime = date.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays < 7) return `In ${diffDays} days`;
    return date.toLocaleDateString();
  };

  const handleAddReminder = () => {
    const reminder: Reminder = {
      id: Date.now().toString(),
      ...newReminder,
      isActive: true,
      nextDue: new Date(), // This would be calculated based on frequency
      completed: false
    };
    
    setReminders(prev => [...prev, reminder]);
    setNewReminder({
      title: '',
      type: 'medication',
      time: '',
      frequency: 'daily',
      dosage: '',
      notes: ''
    });
    setIsDialogOpen(false);
    console.log('Reminder added:', reminder);
  };

  const handleCompleteReminder = (id: string) => {
    setReminders(prev => 
      prev.map(r => r.id === id ? { ...r, completed: !r.completed } : r)
    );
    console.log('Reminder completed:', id);
  };

  const handleDeleteReminder = (id: string) => {
    setReminders(prev => prev.filter(r => r.id !== id));
    console.log('Reminder deleted:', id);
  };

  const todayReminders = reminders.filter(r => {
    const today = new Date();
    const reminderDate = new Date(r.nextDue);
    return reminderDate.toDateString() === today.toDateString();
  });

  const upcomingReminders = reminders.filter(r => {
    const today = new Date();
    const reminderDate = new Date(r.nextDue);
    return reminderDate > today;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Reminders</h2>
          <p className="text-muted-foreground">Manage your medications, appointments, and health tasks</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-reminder">
              <Plus className="h-4 w-4 mr-2" />
              Add Reminder
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Add New Reminder</DialogTitle>
              <DialogDescription>
                Create a new reminder for medications, appointments, or health tasks.
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={newReminder.title}
                  onChange={(e) => setNewReminder(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g., Take Metformin"
                  data-testid="input-reminder-title"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="type">Type</Label>
                <Select 
                  value={newReminder.type} 
                  onValueChange={(value: any) => setNewReminder(prev => ({ ...prev, type: value }))}
                >
                  <SelectTrigger data-testid="select-reminder-type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="medication">Medication</SelectItem>
                    <SelectItem value="appointment">Appointment</SelectItem>
                    <SelectItem value="test">Health Test</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="time">Time</Label>
                  <Input
                    id="time"
                    type="time"
                    value={newReminder.time}
                    onChange={(e) => setNewReminder(prev => ({ ...prev, time: e.target.value }))}
                    data-testid="input-reminder-time"
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="frequency">Frequency</Label>
                  <Select 
                    value={newReminder.frequency} 
                    onValueChange={(value: any) => setNewReminder(prev => ({ ...prev, frequency: value }))}
                  >
                    <SelectTrigger data-testid="select-reminder-frequency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="once">Once</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {newReminder.type === 'medication' && (
                <div className="grid gap-2">
                  <Label htmlFor="dosage">Dosage</Label>
                  <Input
                    id="dosage"
                    value={newReminder.dosage}
                    onChange={(e) => setNewReminder(prev => ({ ...prev, dosage: e.target.value }))}
                    placeholder="e.g., 500mg"
                    data-testid="input-reminder-dosage"
                  />
                </div>
              )}
              
              <div className="grid gap-2">
                <Label htmlFor="notes">Notes</Label>
                <Input
                  id="notes"
                  value={newReminder.notes}
                  onChange={(e) => setNewReminder(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="Additional notes..."
                  data-testid="input-reminder-notes"
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                type="submit" 
                onClick={handleAddReminder}
                disabled={!newReminder.title || !newReminder.time}
                data-testid="button-save-reminder"
              >
                Save Reminder
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="today" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="today" data-testid="tab-today">
            Today ({todayReminders.length})
          </TabsTrigger>
          <TabsTrigger value="upcoming" data-testid="tab-upcoming">
            Upcoming ({upcomingReminders.length})
          </TabsTrigger>
          <TabsTrigger value="all" data-testid="tab-all">
            All ({reminders.length})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="today" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Today's Reminders</CardTitle>
              <CardDescription>
                Tasks scheduled for today
              </CardDescription>
            </CardHeader>
            <CardContent>
              {todayReminders.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  No reminders for today
                </p>
              ) : (
                <div className="space-y-3">
                  {todayReminders.map((reminder) => (
                    <div 
                      key={reminder.id} 
                      className={`flex items-center justify-between p-4 border rounded-lg hover-elevate ${
                        reminder.completed ? 'opacity-60' : ''
                      }`}
                      data-testid={`reminder-${reminder.id}`}
                    >
                      <div className="flex items-center gap-4">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleCompleteReminder(reminder.id)}
                          className={reminder.completed ? 'text-green-600' : ''}
                          data-testid={`complete-${reminder.id}`}
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                        
                        <div className="flex items-center gap-3">
                          {getTypeIcon(reminder.type)}
                          <div>
                            <p className={`font-medium ${reminder.completed ? 'line-through' : ''}`}>
                              {reminder.title}
                            </p>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              <span>{formatTime(reminder.time)}</span>
                              {reminder.dosage && (
                                <Badge variant="outline" className="text-xs">
                                  {reminder.dosage}
                                </Badge>
                              )}
                            </div>
                            {reminder.notes && (
                              <p className="text-xs text-muted-foreground mt-1">
                                {reminder.notes}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge variant={getTypeColor(reminder.type) as any}>
                          {reminder.type}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteReminder(reminder.id)}
                          data-testid={`delete-${reminder.id}`}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="upcoming" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Reminders</CardTitle>
              <CardDescription>
                Scheduled for the future
              </CardDescription>
            </CardHeader>
            <CardContent>
              {upcomingReminders.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  No upcoming reminders
                </p>
              ) : (
                <div className="space-y-3">
                  {upcomingReminders.map((reminder) => (
                    <div 
                      key={reminder.id} 
                      className="flex items-center justify-between p-4 border rounded-lg hover-elevate"
                      data-testid={`upcoming-${reminder.id}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-3">
                          {getTypeIcon(reminder.type)}
                          <div>
                            <p className="font-medium">{reminder.title}</p>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Calendar className="h-3 w-3" />
                              <span>{formatNextDue(reminder.nextDue)}</span>
                              <Clock className="h-3 w-3" />
                              <span>{formatTime(reminder.time)}</span>
                              {reminder.dosage && (
                                <Badge variant="outline" className="text-xs">
                                  {reminder.dosage}
                                </Badge>
                              )}
                            </div>
                            {reminder.notes && (
                              <p className="text-xs text-muted-foreground mt-1">
                                {reminder.notes}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge variant={getTypeColor(reminder.type) as any}>
                          {reminder.type}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="icon"
                          data-testid={`edit-${reminder.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteReminder(reminder.id)}
                          data-testid={`delete-upcoming-${reminder.id}`}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Reminders</CardTitle>
              <CardDescription>
                Complete list of your reminders
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {reminders.map((reminder) => (
                  <div 
                    key={reminder.id} 
                    className={`flex items-center justify-between p-4 border rounded-lg hover-elevate ${
                      reminder.completed ? 'opacity-60' : ''
                    }`}
                    data-testid={`all-${reminder.id}`}
                  >
                    <div className="flex items-center gap-4">
                      {formatNextDue(reminder.nextDue) === 'Today' && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleCompleteReminder(reminder.id)}
                          className={reminder.completed ? 'text-green-600' : ''}
                          data-testid={`complete-all-${reminder.id}`}
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                      )}
                      
                      <div className="flex items-center gap-3">
                        {getTypeIcon(reminder.type)}
                        <div>
                          <p className={`font-medium ${reminder.completed ? 'line-through' : ''}`}>
                            {reminder.title}
                          </p>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Calendar className="h-3 w-3" />
                            <span>{formatNextDue(reminder.nextDue)}</span>
                            <Clock className="h-3 w-3" />
                            <span>{formatTime(reminder.time)}</span>
                            <Badge variant="outline" className="text-xs capitalize">
                              {reminder.frequency}
                            </Badge>
                            {reminder.dosage && (
                              <Badge variant="outline" className="text-xs">
                                {reminder.dosage}
                              </Badge>
                            )}
                          </div>
                          {reminder.notes && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {reminder.notes}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Badge variant={getTypeColor(reminder.type) as any}>
                        {reminder.type}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteReminder(reminder.id)}
                        data-testid={`delete-all-${reminder.id}`}
                        className="text-red-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}