import { useState } from "react";
import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Upload, 
  TrendingUp, 
  MessageSquare, 
  Bell, 
  FileText, 
  Settings, 
  LogOut,
  Heart,
  Moon,
  Sun
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface MainLayoutProps {
  children: React.ReactNode;
  currentUser?: {
    name: string;
    email: string;
    avatar?: string;
  };
  onNavigate: (page: string) => void;
  onLogout: () => void;
  currentPage: string;
}

export default function MainLayout({ children, currentUser, onNavigate, onLogout, currentPage }: MainLayoutProps) {
  const [isDark, setIsDark] = useState(false);

  const menuItems = [
    { 
      id: "dashboard", 
      title: "Dashboard", 
      icon: TrendingUp,
      description: "Overview & Analytics" 
    },
    { 
      id: "upload", 
      title: "Upload Report", 
      icon: Upload,
      description: "New Medical Report" 
    },
    { 
      id: "reports", 
      title: "My Reports", 
      icon: FileText,
      description: "View All Reports" 
    },
    { 
      id: "timeline", 
      title: "Health Timeline", 
      icon: TrendingUp,
      description: "Track Your Progress" 
    },
    { 
      id: "chat", 
      title: "Doctor Chat", 
      icon: MessageSquare,
      description: "Consult with Doctors",
      badge: 3 
    },
    { 
      id: "reminders", 
      title: "Reminders", 
      icon: Bell,
      description: "Medication & Tests",
      badge: 2 
    },
  ];

  const handleThemeToggle = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle('dark');
    console.log('Theme toggled to:', isDark ? 'light' : 'dark');
  };

  const handleNavigation = (page: string) => {
    onNavigate(page);
    console.log('Navigating to:', page);
  };

  const handleLogout = () => {
    onLogout();
    console.log('Logout triggered');
  };

  const style = {
    "--sidebar-width": "18rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <Sidebar className="border-r">
          <SidebarHeader className="border-b p-4">
            <div className="flex items-center gap-3">
              <div className="bg-primary rounded-lg p-2">
                <Heart className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h2 className="font-semibold text-lg">MediReport</h2>
                <p className="text-xs text-muted-foreground">AI Interpreter</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupLabel>Navigation</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-1">
                  {menuItems.map((item) => (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton
                        onClick={() => handleNavigation(item.id)}
                        data-testid={`nav-${item.id}`}
                        className={`w-full justify-start gap-3 hover-elevate ${
                          currentPage === item.id ? 'bg-sidebar-accent' : ''
                        }`}
                      >
                        <item.icon className="h-4 w-4" />
                        <div className="flex-1 text-left">
                          <div className="font-medium">{item.title}</div>
                          <div className="text-xs text-muted-foreground">{item.description}</div>
                        </div>
                        {item.badge && (
                          <Badge variant="secondary" className="ml-auto">
                            {item.badge}
                          </Badge>
                        )}
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-auto">
              <SidebarGroupLabel>Account</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      onClick={() => handleNavigation('settings')}
                      data-testid="nav-settings"
                      className="w-full justify-start gap-3 hover-elevate"
                    >
                      <Settings className="h-4 w-4" />
                      <span>Settings</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      onClick={handleLogout}
                      data-testid="button-logout"
                      className="w-full justify-start gap-3 hover-elevate text-destructive"
                    >
                      <LogOut className="h-4 w-4" />
                      <span>Logout</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <div className="flex flex-col flex-1">
          <header className="flex items-center justify-between p-4 border-b bg-card">
            <div className="flex items-center gap-3">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <h1 className="font-semibold text-lg capitalize">
                {currentPage.replace(/([A-Z])/g, ' $1').trim()}
              </h1>
            </div>
            
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleThemeToggle}
                data-testid="button-theme-toggle"
              >
                {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
              
              {currentUser && (
                <div className="flex items-center gap-3 pl-3 border-l">
                  <div className="text-right">
                    <div className="font-medium text-sm">{currentUser.name}</div>
                    <div className="text-xs text-muted-foreground">{currentUser.email}</div>
                  </div>
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={currentUser.avatar} />
                    <AvatarFallback>
                      {currentUser.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                </div>
              )}
            </div>
          </header>

          <main className="flex-1 overflow-auto p-6 bg-background">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}