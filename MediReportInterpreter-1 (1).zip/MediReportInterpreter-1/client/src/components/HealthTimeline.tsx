import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  BarChart, 
  Bar 
} from "recharts";
import { 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Heart, 
  Activity, 
  Thermometer,
  Droplets
} from "lucide-react";

interface HealthMetric {
  id: string;
  name: string;
  icon: React.ReactNode;
  value: string;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  riskLevel: 'normal' | 'warning' | 'critical';
  lastUpdated: string;
  referenceRange: string;
}

interface HealthTimelineProps {
  userId?: string;
}

export default function HealthTimeline({ userId }: HealthTimelineProps) {
  // todo: remove mock functionality - replace with real data from Firestore
  const [selectedPeriod, setSelectedPeriod] = useState('3m');

  const healthMetrics: HealthMetric[] = [
    {
      id: 'blood-sugar',
      name: 'Blood Sugar',
      icon: <Droplets className="h-4 w-4" />,
      value: '120',
      unit: 'mg/dL',
      trend: 'stable',
      riskLevel: 'normal',
      lastUpdated: '2024-01-15',
      referenceRange: '70-140 mg/dL'
    },
    {
      id: 'blood-pressure',
      name: 'Blood Pressure',
      icon: <Heart className="h-4 w-4" />,
      value: '140/90',
      unit: 'mmHg',
      trend: 'up',
      riskLevel: 'warning',
      lastUpdated: '2024-01-15',
      referenceRange: '<120/80 mmHg'
    },
    {
      id: 'cholesterol',
      name: 'Cholesterol',
      icon: <Activity className="h-4 w-4" />,
      value: '200',
      unit: 'mg/dL',
      trend: 'down',
      riskLevel: 'normal',
      lastUpdated: '2024-01-10',
      referenceRange: '<200 mg/dL'
    },
    {
      id: 'heart-rate',
      name: 'Heart Rate',
      icon: <Thermometer className="h-4 w-4" />,
      value: '72',
      unit: 'bpm',
      trend: 'stable',
      riskLevel: 'normal',
      lastUpdated: '2024-01-15',
      referenceRange: '60-100 bpm'
    }
  ];

  const bloodSugarData = [
    { date: '2023-10-01', value: 110 },
    { date: '2023-10-15', value: 115 },
    { date: '2023-11-01', value: 108 },
    { date: '2023-11-15', value: 120 },
    { date: '2023-12-01', value: 118 },
    { date: '2023-12-15', value: 125 },
    { date: '2024-01-01', value: 122 },
    { date: '2024-01-15', value: 120 },
  ];

  const bloodPressureData = [
    { date: '2023-10-01', systolic: 130, diastolic: 85 },
    { date: '2023-10-15', systolic: 135, diastolic: 87 },
    { date: '2023-11-01', systolic: 132, diastolic: 84 },
    { date: '2023-11-15', systolic: 138, diastolic: 89 },
    { date: '2023-12-01', systolic: 140, diastolic: 90 },
    { date: '2023-12-15', systolic: 142, diastolic: 92 },
    { date: '2024-01-01', systolic: 145, diastolic: 93 },
    { date: '2024-01-15', systolic: 140, diastolic: 90 },
  ];

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-red-500" />;
      case 'down':
        return <TrendingDown className="h-4 w-4 text-green-500" />;
      default:
        return <div className="h-4 w-4 rounded-full bg-gray-400" />;
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'critical':
        return 'destructive';
      case 'warning':
        return 'secondary';
      default:
        return 'default';
    }
  };

  const handlePeriodChange = (period: string) => {
    setSelectedPeriod(period);
    console.log('Period changed to:', period);
  };

  const handleMetricClick = (metricId: string) => {
    console.log('Metric clicked:', metricId);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Health Timeline</h2>
          <p className="text-muted-foreground">Track your health metrics over time</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={selectedPeriod === '1m' ? 'default' : 'outline'}
            size="sm"
            onClick={() => handlePeriodChange('1m')}
            data-testid="period-1m"
          >
            1M
          </Button>
          <Button
            variant={selectedPeriod === '3m' ? 'default' : 'outline'}
            size="sm"
            onClick={() => handlePeriodChange('3m')}
            data-testid="period-3m"
          >
            3M
          </Button>
          <Button
            variant={selectedPeriod === '6m' ? 'default' : 'outline'}
            size="sm"
            onClick={() => handlePeriodChange('6m')}
            data-testid="period-6m"
          >
            6M
          </Button>
          <Button
            variant={selectedPeriod === '1y' ? 'default' : 'outline'}
            size="sm"
            onClick={() => handlePeriodChange('1y')}
            data-testid="period-1y"
          >
            1Y
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {healthMetrics.map((metric) => (
          <Card 
            key={metric.id} 
            className="hover-elevate cursor-pointer"
            onClick={() => handleMetricClick(metric.id)}
            data-testid={`metric-${metric.id}`}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {metric.icon}
                  <span className="font-medium text-sm">{metric.name}</span>
                </div>
                {getTrendIcon(metric.trend)}
              </div>
              
              <div className="space-y-2">
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold">{metric.value}</span>
                  <span className="text-sm text-muted-foreground">{metric.unit}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <Badge variant={getRiskColor(metric.riskLevel) as any} className="text-xs">
                    {metric.riskLevel}
                  </Badge>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {metric.lastUpdated}
                  </span>
                </div>
                
                <p className="text-xs text-muted-foreground">
                  Range: {metric.referenceRange}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="blood-sugar" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="blood-sugar" data-testid="tab-blood-sugar">Blood Sugar</TabsTrigger>
          <TabsTrigger value="blood-pressure" data-testid="tab-blood-pressure">Blood Pressure</TabsTrigger>
          <TabsTrigger value="trends" data-testid="tab-trends">All Trends</TabsTrigger>
        </TabsList>
        
        <TabsContent value="blood-sugar" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Blood Sugar Levels</CardTitle>
              <CardDescription>
                Track your glucose levels over the selected period
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={bloodSugarData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(date) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    />
                    <YAxis 
                      domain={[80, 150]} 
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip 
                      labelFormatter={(date) => `Date: ${new Date(date).toLocaleDateString()}`}
                      formatter={(value: any) => [`${value} mg/dL`, 'Blood Sugar']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="blood-pressure" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Blood Pressure Readings</CardTitle>
              <CardDescription>
                Monitor systolic and diastolic pressure trends
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={bloodPressureData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(date) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    />
                    <YAxis 
                      domain={[60, 160]} 
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip 
                      labelFormatter={(date) => `Date: ${new Date(date).toLocaleDateString()}`}
                      formatter={(value: any, name: string) => [`${value} mmHg`, name === 'systolic' ? 'Systolic' : 'Diastolic']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="systolic" 
                      stroke="hsl(var(--chart-1))" 
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--chart-1))", strokeWidth: 2, r: 4 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="diastolic" 
                      stroke="hsl(var(--chart-2))" 
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--chart-2))", strokeWidth: 2, r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Health Metrics</CardTitle>
              <CardDescription>
                Overview of all your health indicators
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[
                    { name: 'Blood Sugar', current: 120, target: 110 },
                    { name: 'Systolic BP', current: 140, target: 120 },
                    { name: 'Diastolic BP', current: 90, target: 80 },
                    { name: 'Cholesterol', current: 200, target: 180 },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="current" fill="hsl(var(--primary))" name="Current" />
                    <Bar dataKey="target" fill="hsl(var(--chart-2))" name="Target" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}