import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Send, 
  Paperclip, 
  Phone, 
  Video, 
  MoreVertical,
  Clock,
  Check,
  CheckCheck
} from "lucide-react";

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: 'patient' | 'doctor';
  content: string;
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
  attachments?: {
    type: 'report' | 'image';
    name: string;
    url: string;
  }[];
}

interface ChatRoom {
  id: string;
  doctorName: string;
  doctorSpecialty: string;
  doctorAvatar?: string;
  isOnline: boolean;
  lastSeen?: Date;
}

interface ChatInterfaceProps {
  currentUserId: string;
  currentChatRoom?: ChatRoom;
  onSendMessage: (content: string, attachments?: File[]) => void;
  onCallDoctor: (type: 'voice' | 'video') => void;
}

export default function ChatInterface({ 
  currentUserId, 
  currentChatRoom, 
  onSendMessage, 
  onCallDoctor 
}: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // todo: remove mock functionality - replace with real Firestore chat data
  const mockMessages: Message[] = [
    {
      id: '1',
      senderId: 'doctor-1',
      senderName: 'Dr. Sarah Wilson',
      senderRole: 'doctor',
      content: 'Hello! I\'ve reviewed your latest blood test results. Overall, they look quite good, but I\'d like to discuss a few points with you.',
      timestamp: new Date('2024-01-15T10:30:00'),
      status: 'read'
    },
    {
      id: '2',
      senderId: currentUserId,
      senderName: 'You',
      senderRole: 'patient',
      content: 'Thank you, Doctor. I was a bit worried about the cholesterol levels. Are they concerning?',
      timestamp: new Date('2024-01-15T10:32:00'),
      status: 'read'
    },
    {
      id: '3',
      senderId: 'doctor-1',
      senderName: 'Dr. Sarah Wilson',
      senderRole: 'doctor',
      content: 'Your cholesterol is slightly elevated at 200 mg/dL, but it\'s not in the danger zone. We should focus on dietary changes and I\'ll prescribe a mild medication to help bring it down.',
      timestamp: new Date('2024-01-15T10:35:00'),
      status: 'read'
    },
    {
      id: '4',
      senderId: currentUserId,
      senderName: 'You',
      senderRole: 'patient',
      content: 'What kind of dietary changes would you recommend?',
      timestamp: new Date('2024-01-15T10:37:00'),
      status: 'delivered'
    },
    {
      id: '5',
      senderId: 'doctor-1',
      senderName: 'Dr. Sarah Wilson',
      senderRole: 'doctor',
      content: 'I recommend reducing saturated fats, increasing fiber intake with oats and beans, and adding more omega-3 rich fish like salmon. I\'ll send you a detailed diet plan.',
      timestamp: new Date('2024-01-15T10:40:00'),
      status: 'sent'
    }
  ];

  useEffect(() => {
    setMessages(mockMessages);
  }, [currentUserId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        senderId: currentUserId,
        senderName: 'You',
        senderRole: 'patient',
        content: message,
        timestamp: new Date(),
        status: 'sent'
      };
      
      setMessages(prev => [...prev, newMessage]);
      onSendMessage(message);
      setMessage("");
      console.log('Message sent:', message);
    }
  };

  const handleCall = (type: 'voice' | 'video') => {
    onCallDoctor(type);
    console.log(`${type} call initiated`);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
        return <Check className="h-3 w-3" />;
      case 'delivered':
        return <CheckCheck className="h-3 w-3" />;
      case 'read':
        return <CheckCheck className="h-3 w-3 text-blue-500" />;
      default:
        return null;
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  if (!currentChatRoom) {
    return (
      <Card className="h-[600px] flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">Select a doctor to start chatting</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={currentChatRoom.doctorAvatar} />
              <AvatarFallback>
                {currentChatRoom.doctorName.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-lg">{currentChatRoom.doctorName}</CardTitle>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  {currentChatRoom.doctorSpecialty}
                </Badge>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <div className={`h-2 w-2 rounded-full ${
                    currentChatRoom.isOnline ? 'bg-green-500' : 'bg-gray-400'
                  }`} />
                  <span>
                    {currentChatRoom.isOnline ? 'Online' : 'Last seen 2h ago'}
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleCall('voice')}
              data-testid="button-voice-call"
            >
              <Phone className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleCall('video')}
              data-testid="button-video-call"
            >
              <Video className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              data-testid="button-chat-options"
            >
              <MoreVertical className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-full p-4">
          <div className="space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${
                  msg.senderId === currentUserId ? 'justify-end' : 'justify-start'
                }`}
              >
                <div
                  className={`max-w-[70%] rounded-lg p-3 ${
                    msg.senderId === currentUserId
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted'
                  }`}
                  data-testid={`message-${msg.id}`}
                >
                  {msg.senderRole === 'doctor' && msg.senderId !== currentUserId && (
                    <p className="text-xs font-medium mb-1 opacity-75">
                      {msg.senderName}
                    </p>
                  )}
                  
                  <p className="text-sm">{msg.content}</p>
                  
                  <div className={`flex items-center justify-end gap-1 mt-2 text-xs ${
                    msg.senderId === currentUserId 
                      ? 'text-primary-foreground/70' 
                      : 'text-muted-foreground'
                  }`}>
                    <Clock className="h-3 w-3" />
                    <span>{formatTime(msg.timestamp)}</span>
                    {msg.senderId === currentUserId && getStatusIcon(msg.status)}
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </CardContent>

      <div className="border-t p-4">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            data-testid="button-attach-file"
          >
            <Paperclip className="h-4 w-4" />
          </Button>
          
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-1"
            data-testid="input-message"
          />
          
          <Button 
            type="submit" 
            size="icon"
            disabled={!message.trim()}
            data-testid="button-send-message"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </Card>
  );
}