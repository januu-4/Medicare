import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Upload, 
  File, 
  FileText, 
  Image, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  X,
  AlertTriangle,
  Info,
  TrendingUp,
  TrendingDown,
  Languages,
  Globe
} from "lucide-react";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth } from "@/lib/firebase";

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
  ocrText?: string;
  analysisResult?: any;
  reportId?: string;
}

interface FileUploadProps {
  onFileAnalyzed: (file: UploadedFile) => void;
  maxFiles?: number;
  acceptedTypes?: string[];
}

// Supported languages for OCR and translation (matches backend validation)
const SUPPORTED_LANGUAGES = {
  'eng': 'English',
  'spa': 'Spanish', 
  'fra': 'French',
  'deu': 'German',
  'ita': 'Italian',
  'por': 'Portuguese',
  'rus': 'Russian',
  'chi_sim': 'Chinese (Simplified)',
  'chi_tra': 'Chinese (Traditional)',
  'jpn': 'Japanese',
  'kor': 'Korean',
  'ara': 'Arabic',
  'hin': 'Hindi'
};

export default function FileUpload({ onFileAnalyzed, maxFiles = 5, acceptedTypes = ['image/*', 'application/pdf'] }: FileUploadProps) {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [ocrLanguage, setOcrLanguage] = useState<string>('eng');
  const [translationLanguage, setTranslationLanguage] = useState<string>('eng');
  const [user, loading] = useAuthState(auth);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('userId', user?.uid || '');
      formData.append('fileName', file.name);
      formData.append('fileType', file.type);
      formData.append('ocrLanguage', ocrLanguage);
      formData.append('translationLanguage', translationLanguage);
      
      return apiRequest('/api/process-report', {
        method: 'POST',
        body: formData,
      });
    },
    onSuccess: (data, file) => {
      setUploadedFiles(prev => 
        prev.map(f => 
          f.name === file.name 
            ? { ...f, status: 'completed', reportId: data.reportId, analysisResult: data.extractedData }
            : f
        )
      );
      
      // Invalidate reports query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/reports'] });
      
      const finalFile = uploadedFiles.find(f => f.name === file.name);
      if (finalFile) {
        onFileAnalyzed({ ...finalFile, status: 'completed', reportId: data.reportId, analysisResult: data.extractedData });
      }
      
      toast({
        title: "File processed successfully",
        description: `${file.name} has been analyzed and saved.`,
      });
    },
    onError: (error, file) => {
      setUploadedFiles(prev => 
        prev.map(f => 
          f.name === file.name 
            ? { ...f, status: 'error', progress: 0 }
            : f
        )
      );
      
      toast({
        title: "Upload failed",
        description: `Failed to process ${file.name}. Please try again.`,
        variant: "destructive",
      });
    },
  });

  const processFile = async (originalFile: File, uploadedFile: UploadedFile) => {
    // Update status to processing
    setUploadedFiles(prev => 
      prev.map(f => f.id === uploadedFile.id ? { ...f, status: 'processing', progress: 100 } : f)
    );
    
    // Start the actual upload and processing
    uploadMutation.mutate(originalFile);
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to upload files.",
        variant: "destructive",
      });
      return;
    }

    const newFiles: UploadedFile[] = acceptedFiles.map(file => ({
      id: Math.random().toString(36),
      name: file.name,
      size: file.size,
      type: file.type,
      status: 'uploading',
      progress: 0
    }));

    setUploadedFiles(prev => [...prev, ...newFiles]);

    // Process each file
    newFiles.forEach((uploadedFile, index) => {
      const originalFile = acceptedFiles[index];
      
      // Simulate upload progress first
      let progress = 0;
      const progressInterval = setInterval(() => {
        progress += Math.random() * 25;
        if (progress >= 100) {
          clearInterval(progressInterval);
          processFile(originalFile, uploadedFile);
        } else {
          setUploadedFiles(prev => 
            prev.map(f => f.id === uploadedFile.id ? { ...f, progress } : f)
          );
        }
      }, 200);
    });
  }, [user, toast, uploadMutation]);

  const removeFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg'],
      'application/pdf': ['.pdf']
    },
    maxFiles,
    multiple: true
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return <Image className="h-5 w-5" />;
    if (type === 'application/pdf') return <FileText className="h-5 w-5" />;
    return <File className="h-5 w-5" />;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'uploading':
      case 'processing':
        return <Loader2 className="h-4 w-4 animate-spin" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'uploading':
        return 'default';
      case 'processing':
        return 'secondary';
      case 'completed':
        return 'default';
      case 'error':
        return 'destructive';
      default:
        return 'default';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical':
        return { bg: '#fef2f2', border: '#fecaca' }; // red-50/red-200
      case 'severe':
        return { bg: '#fef3c7', border: '#fde68a' }; // yellow-50/yellow-200  
      case 'moderate':
        return { bg: '#fef3c7', border: '#fde68a' }; // yellow-50/yellow-200
      case 'mild':
        return { bg: '#f0f9ff', border: '#bae6fd' }; // blue-50/blue-200
      case 'normal':
      default:
        return { bg: '#f0fdf4', border: '#bbf7d0' }; // green-50/green-200
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case 'severe':
        return <AlertCircle className="h-4 w-4 text-orange-600" />;
      case 'moderate':
        return <AlertCircle className="h-4 w-4 text-yellow-600" />;
      case 'mild':
        return <Info className="h-4 w-4 text-blue-600" />;
      case 'normal':
      default:
        return <CheckCircle className="h-4 w-4 text-green-600" />;
    }
  };

  const getSeverityBadgeVariant = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical':
      case 'severe':
        return 'destructive';
      case 'moderate':
        return 'secondary';
      case 'mild':
        return 'outline';
      case 'normal':
      default:
        return 'default';
    }
  };

  const getUrgencyBadgeVariant = (urgency: string) => {
    switch (urgency?.toLowerCase()) {
      case 'immediate':
        return 'destructive';
      case 'soon':
        return 'secondary';
      case 'routine':
      default:
        return 'outline';
    }
  };

  // Show auth message if user is not logged in
  if (!user && !loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload Medical Reports
          </CardTitle>
          <CardDescription>
            Please sign in to upload and analyze your medical reports.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center py-8">
          <p className="text-muted-foreground mb-4">Authentication required to access this feature</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload Medical Reports
          </CardTitle>
          <CardDescription>
            Upload your medical reports, lab results, or prescriptions. We support PDF files and images.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Language Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 p-4 bg-muted/50 rounded-lg border">
            <div className="space-y-2">
              <Label htmlFor="ocr-language" className="text-sm font-medium flex items-center gap-2">
                <Languages className="h-4 w-4" />
                OCR Language
              </Label>
              <Select value={ocrLanguage} onValueChange={setOcrLanguage}>
                <SelectTrigger id="ocr-language" data-testid="select-ocr-language">
                  <SelectValue placeholder="Select OCR language" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(SUPPORTED_LANGUAGES).map(([code, name]) => (
                    <SelectItem key={code} value={code}>
                      {name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Language of the text in your prescription or document
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="translation-language" className="text-sm font-medium flex items-center gap-2">
                <Globe className="h-4 w-4" />
                Translation Language
              </Label>
              <Select value={translationLanguage} onValueChange={setTranslationLanguage}>
                <SelectTrigger id="translation-language" data-testid="select-translation-language">
                  <SelectValue placeholder="Select translation language" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(SUPPORTED_LANGUAGES).map(([code, name]) => (
                    <SelectItem key={code} value={code}>
                      {name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Language you want the analysis translated to
              </p>
            </div>
          </div>

          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors hover-elevate ${
              isDragActive 
                ? 'border-primary bg-primary/10' 
                : 'border-muted-foreground/25 hover:border-primary/50'
            }`}
            data-testid="dropzone-upload"
          >
            <input {...getInputProps()} />
            <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            {isDragActive ? (
              <p className="text-lg font-medium">Drop your files here...</p>
            ) : (
              <div>
                <p className="text-lg font-medium mb-2">Drag & drop files here</p>
                <p className="text-muted-foreground mb-4">or click to browse</p>
                <Button variant="outline" data-testid="button-browse-files">
                  Browse Files
                </Button>
              </div>
            )}
            <p className="text-xs text-muted-foreground mt-4">
              Supports PDF, JPG, PNG files up to 10MB each
            </p>
          </div>
        </CardContent>
      </Card>

      {uploadedFiles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Processing Files</CardTitle>
            <CardDescription>
              Your files are being processed with OCR and AI analysis
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {uploadedFiles.map((file) => (
              <div key={file.id} className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="flex-shrink-0">
                  {getFileIcon(file.type)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium truncate">{file.name}</p>
                    <div className="flex items-center gap-2">
                      <Badge variant={getStatusColor(file.status) as any}>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(file.status)}
                          <span className="capitalize">{file.status}</span>
                        </div>
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeFile(file.id)}
                        data-testid={`button-remove-${file.id}`}
                        className="h-6 w-6"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
                    <span>{formatFileSize(file.size)}</span>
                    {file.status === 'uploading' && (
                      <span>{Math.round(file.progress)}%</span>
                    )}
                  </div>
                  
                  {(file.status === 'uploading' || file.status === 'processing') && (
                    <Progress value={file.progress} className="h-2" />
                  )}
                  
                  {file.status === 'completed' && file.analysisResult && (
                    <div className="mt-4 space-y-3">
                      {/* Overall Severity and Risk Level */}
                      <div className="flex items-center justify-between p-3 rounded-lg border" style={{
                        backgroundColor: getSeverityColor(file.analysisResult.overallSeverity).bg,
                        borderColor: getSeverityColor(file.analysisResult.overallSeverity).border
                      }}>
                        <div className="flex items-center gap-2">
                          {getSeverityIcon(file.analysisResult.overallSeverity)}
                          <div>
                            <p className="text-sm font-medium">Health Assessment</p>
                            <p className="text-xs text-muted-foreground">
                              Severity: {file.analysisResult.overallSeverity?.toUpperCase() || 'NORMAL'} | Risk: {file.analysisResult.riskLevel?.toUpperCase() || 'LOW'}
                            </p>
                          </div>
                        </div>
                        <Badge variant={getSeverityBadgeVariant(file.analysisResult.overallSeverity)}>
                          {file.analysisResult.overallSeverity || 'Normal'}
                        </Badge>
                      </div>

                      {/* Abnormal Results Highlighting */}
                      {file.analysisResult.abnormalResults && file.analysisResult.abnormalResults.length > 0 && (
                        <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <AlertTriangle className="h-4 w-4 text-red-600" />
                            <p className="text-sm font-medium text-red-800 dark:text-red-200">Abnormal Results Found</p>
                          </div>
                          <div className="space-y-2">
                            {file.analysisResult.abnormalResults.map((abnormal: any, index: number) => (
                              <div key={index} className="p-2 bg-white dark:bg-red-900/20 rounded border border-red-100 dark:border-red-700">
                                <div className="flex items-center justify-between mb-1">
                                  <span className="text-sm font-medium text-red-700 dark:text-red-300">
                                    {abnormal.parameter}
                                  </span>
                                  <div className="flex items-center gap-1">
                                    {abnormal.status?.includes('high') ? <TrendingUp className="h-3 w-3 text-red-600" /> : <TrendingDown className="h-3 w-3 text-red-600" />}
                                    <Badge variant="destructive" className="text-xs">
                                      {abnormal.severity || abnormal.status}
                                    </Badge>
                                  </div>
                                </div>
                                <p className="text-xs text-muted-foreground mb-1">
                                  Value: <span className="font-medium text-red-600">{abnormal.value}</span>
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {abnormal.explanation}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Detailed Explanations for Abnormal Results */}
                      {file.analysisResult.abnormalExplanations && file.analysisResult.abnormalExplanations.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-sm font-medium flex items-center gap-2">
                            <Info className="h-4 w-4" />
                            What This Means for You
                          </p>
                          {file.analysisResult.abnormalExplanations.map((explanation: any, index: number) => (
                            <div key={index} className="p-3 border rounded-lg bg-card">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-sm font-medium">{explanation.parameter}</span>
                                <Badge variant={getUrgencyBadgeVariant(explanation.urgency)}>
                                  {explanation.urgency}
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground mb-2">
                                {explanation.simpleExplanation}
                              </p>
                              <div className="text-xs">
                                <p className="font-medium mb-1">What you should do:</p>
                                <p className="text-muted-foreground">{explanation.actionNeeded}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* General Analysis */}
                      <div className="p-3 bg-muted rounded-lg">
                        <p className="text-sm font-medium mb-1">Overall Analysis</p>
                        <p className="text-xs text-muted-foreground mb-2">
                          {file.analysisResult.explanation}
                        </p>
                        {file.analysisResult.nextSteps && (
                          <div className="mt-2 pt-2 border-t">
                            <p className="text-xs font-medium mb-1">Next Steps:</p>
                            <p className="text-xs text-muted-foreground">
                              {file.analysisResult.nextSteps}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}