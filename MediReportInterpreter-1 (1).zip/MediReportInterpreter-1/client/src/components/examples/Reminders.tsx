import Reminders from '../Reminders';

export default function RemindersExample() {
  return (
    <div className="max-w-6xl mx-auto p-6">
      <Reminders userId="mock-user-123" />
    </div>
  );
}