import Dashboard from '../Dashboard';

export default function DashboardExample() {
  return (
    <div className="max-w-7xl mx-auto p-6">
      <Dashboard
        onNavigate={(page) => console.log('Navigate to:', page)}
        userName="Dr. Sarah Wilson"
      />
    </div>
  );
}