import FileUpload from '../FileUpload';

export default function FileUploadExample() {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <FileUpload
        onFileAnalyzed={(file) => console.log('File analyzed:', file)}
        maxFiles={5}
      />
    </div>
  );
}