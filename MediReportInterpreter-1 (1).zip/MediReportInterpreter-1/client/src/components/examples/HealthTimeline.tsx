import HealthTimeline from '../HealthTimeline';

export default function HealthTimelineExample() {
  return (
    <div className="max-w-6xl mx-auto p-6">
      <HealthTimeline userId="mock-user-123" />
    </div>
  );
}