import AuthForm from '../AuthForm';

export default function AuthFormExample() {
  return (
    <AuthForm
      onLogin={(email, password) => console.log('Login:', { email, password })}
      onRegister={(email, password, name) => console.log('Register:', { email, password, name })}
      onGoogleLogin={() => console.log('Google login')}
    />
  );
}