import MainLayout from '../MainLayout';

export default function MainLayoutExample() {
  return (
    <MainLayout
      currentUser={{
        name: "Dr. Sarah Wilson",
        email: "sarah.wilson@hospital.com"
      }}
      onNavigate={(page) => console.log('Navigate to:', page)}
      onLogout={() => console.log('Logout')}
      currentPage="dashboard"
    >
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Dashboard Content</h2>
        <p className="text-muted-foreground">This is where the main content would appear.</p>
      </div>
    </MainLayout>
  );
}