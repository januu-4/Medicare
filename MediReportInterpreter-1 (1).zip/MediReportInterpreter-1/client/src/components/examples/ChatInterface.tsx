import ChatInterface from '../ChatInterface';

export default function ChatInterfaceExample() {
  const mockChatRoom = {
    id: 'room-1',
    doctorName: 'Dr. Sarah Wilson',
    doctorSpecialty: 'Cardiologist',
    isOnline: true
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <ChatInterface
        currentUserId="patient-123"
        currentChatRoom={mockChatRoom}
        onSendMessage={(content) => console.log('Message sent:', content)}
        onCallDoctor={(type) => console.log('Call initiated:', type)}
      />
    </div>
  );
}