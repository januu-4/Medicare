import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Upload, 
  FileText, 
  MessageSquare, 
  Bell, 
  TrendingUp, 
  Calendar,
  AlertTriangle,
  CheckCircle,
  Clock
} from "lucide-react";

interface DashboardProps {
  onNavigate: (page: string) => void;
  userName?: string;
}

export default function Dashboard({ onNavigate, userName = "Patient" }: DashboardProps) {
  // todo: remove mock functionality - replace with real data from Firestore
  const stats = [
    {
      title: "Reports Uploaded",
      value: "12",
      description: "This month",
      icon: <FileText className="h-4 w-4" />,
      trend: "+3 from last month"
    },
    {
      title: "Health Metrics",
      value: "4",
      description: "Tracked values",
      icon: <TrendingUp className="h-4 w-4" />,
      trend: "Blood sugar, BP, Cholesterol, Heart rate"
    },
    {
      title: "Doctor Messages",
      value: "5",
      description: "Unread messages",
      icon: <MessageSquare className="h-4 w-4" />,
      trend: "2 urgent replies needed"
    },
    {
      title: "Reminders",
      value: "3",
      description: "Pending actions",
      icon: <Bell className="h-4 w-4" />,
      trend: "2 medications, 1 appointment"
    }
  ];

  const recentReports = [
    {
      id: '1',
      name: 'Blood Test Results',
      date: '2024-01-15',
      status: 'analyzed',
      riskLevel: 'normal'
    },
    {
      id: '2',
      name: 'Chest X-Ray Report',
      date: '2024-01-12',
      status: 'analyzed',
      riskLevel: 'normal'
    },
    {
      id: '3',
      name: 'Prescription - Metformin',
      date: '2024-01-10',
      status: 'processing',
      riskLevel: 'warning'
    }
  ];

  const upcomingReminders = [
    {
      id: '1',
      title: 'Take Metformin',
      time: '8:00 AM',
      type: 'medication',
      urgent: false
    },
    {
      id: '2',
      title: 'Blood pressure check',
      time: '2:00 PM',
      type: 'measurement',
      urgent: true
    },
    {
      id: '3',
      title: 'Cardiology appointment',
      time: 'Tomorrow 10:00 AM',
      type: 'appointment',
      urgent: false
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'analyzed':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'processing':
        return <Clock className="h-4 w-4 text-yellow-600" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'normal':
        return 'default';
      case 'warning':
        return 'secondary';
      case 'critical':
        return 'destructive';
      default:
        return 'default';
    }
  };

  const handleQuickAction = (action: string) => {
    onNavigate(action);
    console.log('Quick action:', action);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Welcome back, {userName}!</h1>
        <p className="text-muted-foreground">Here's an overview of your health journey</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <Card key={index} className="hover-elevate">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="p-2 bg-primary/10 rounded-lg">
                  {stat.icon}
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{stat.value}</p>
                <p className="text-sm font-medium">{stat.title}</p>
                <p className="text-xs text-muted-foreground">{stat.description}</p>
                <p className="text-xs text-primary">{stat.trend}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>
                Common tasks to manage your health
              </CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button
                onClick={() => handleQuickAction('upload')}
                className="h-auto p-4 flex flex-col items-center gap-2"
                variant="outline"
                data-testid="quick-upload"
              >
                <Upload className="h-6 w-6" />
                <div className="text-center">
                  <div className="font-medium">Upload Report</div>
                  <div className="text-xs text-muted-foreground">Add new medical document</div>
                </div>
              </Button>
              
              <Button
                onClick={() => handleQuickAction('timeline')}
                className="h-auto p-4 flex flex-col items-center gap-2"
                variant="outline"
                data-testid="quick-timeline"
              >
                <TrendingUp className="h-6 w-6" />
                <div className="text-center">
                  <div className="font-medium">View Timeline</div>
                  <div className="text-xs text-muted-foreground">Track health trends</div>
                </div>
              </Button>
              
              <Button
                onClick={() => handleQuickAction('chat')}
                className="h-auto p-4 flex flex-col items-center gap-2"
                variant="outline"
                data-testid="quick-chat"
              >
                <MessageSquare className="h-6 w-6" />
                <div className="text-center">
                  <div className="font-medium">Chat with Doctor</div>
                  <div className="text-xs text-muted-foreground">Get medical advice</div>
                </div>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Reports</CardTitle>
              <CardDescription>
                Your latest uploaded medical documents
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentReports.map((report) => (
                  <div key={report.id} className="flex items-center justify-between p-3 border rounded-lg hover-elevate">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(report.status)}
                      <div>
                        <p className="font-medium">{report.name}</p>
                        <p className="text-sm text-muted-foreground">{report.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={getRiskColor(report.riskLevel) as any}>
                        {report.riskLevel}
                      </Badge>
                      <Badge variant="outline" className="capitalize">
                        {report.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
              <Button 
                variant="outline" 
                className="w-full mt-4"
                onClick={() => handleQuickAction('reports')}
                data-testid="view-all-reports"
              >
                View All Reports
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Today's Reminders</CardTitle>
              <CardDescription>
                Medications and appointments
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {upcomingReminders.map((reminder) => (
                <div 
                  key={reminder.id} 
                  className={`p-3 border rounded-lg hover-elevate ${
                    reminder.urgent ? 'border-yellow-500 bg-yellow-50 dark:bg-yellow-950/20' : ''
                  }`}
                  data-testid={`reminder-${reminder.id}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <p className="font-medium text-sm">{reminder.title}</p>
                    {reminder.urgent && (
                      <Badge variant="secondary" className="text-xs">
                        Urgent
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    <span>{reminder.time}</span>
                    <Badge variant="outline" className="text-xs capitalize">
                      {reminder.type}
                    </Badge>
                  </div>
                </div>
              ))}
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => handleQuickAction('reminders')}
                data-testid="view-all-reminders"
              >
                View All Reminders
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Health Insights</CardTitle>
              <CardDescription>
                AI-powered recommendations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 border rounded-lg">
                <p className="text-sm font-medium mb-1">Blood Sugar Trend</p>
                <p className="text-xs text-muted-foreground">
                  Your glucose levels have been stable this week. Keep maintaining your current diet.
                </p>
              </div>
              <div className="p-3 border rounded-lg">
                <p className="text-sm font-medium mb-1">Medication Adherence</p>
                <p className="text-xs text-muted-foreground">
                  You've taken 95% of your medications on time this month. Excellent work!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}