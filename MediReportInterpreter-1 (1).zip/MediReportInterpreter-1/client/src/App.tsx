import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth } from "@/lib/firebase";
import { signOutUser, handleRedirectResult } from "@/lib/auth";
import NotFound from "@/pages/not-found";

// Import components
import AuthForm from "@/components/AuthForm";
import MainLayout from "@/components/MainLayout";
import Dashboard from "@/components/Dashboard";
import FileUpload from "@/components/FileUpload";
import HealthTimeline from "@/components/HealthTimeline";
import ChatInterface from "@/components/ChatInterface";
import Reminders from "@/components/Reminders";

function Router() {
  const [user, loading, error] = useAuthState(auth);
  const [currentPage, setCurrentPage] = useState("dashboard");

  // Google OAuth redirect result is now handled in AuthForm component only

  const handleLogout = async () => {
    try {
      await signOutUser();
      setCurrentPage("dashboard");
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const handleFileAnalyzed = (file: any) => {
    console.log('File analyzed:', file);
    // Optionally redirect to reports or timeline page after successful analysis
  };

  const handleAuthSuccess = () => {
    // User successfully authenticated, they'll see the main app
    setCurrentPage("dashboard");
  };

  // Show loading state while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Show authentication error if present
  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-destructive mb-4">Authentication Error</p>
          <p className="text-muted-foreground">{error.message}</p>
        </div>
      </div>
    );
  }

  // If not authenticated, show auth form
  if (!user) {
    return <AuthForm onAuthSuccess={handleAuthSuccess} />;
  }

  // Mock data for chat (would be replaced with real data from Firestore)
  const mockChatRoom = {
    id: 'room-1',
    doctorName: 'Dr. Michael Chen',
    doctorSpecialty: 'Cardiologist',
    isOnline: true
  };

  const handleSendMessage = (content: string) => {
    console.log('Message sent:', content);
    // In real implementation, this would save to Firestore
  };

  const handleCallDoctor = (type: 'voice' | 'video') => {
    console.log('Doctor call initiated:', type);
    // In real implementation, this would initiate a call
  };

  // Render current page content
  const renderPageContent = () => {
    switch (currentPage) {
      case 'dashboard':
        return (
          <Dashboard
            onNavigate={handleNavigate}
            userName={user.displayName || user.email || 'User'}
          />
        );
      case 'upload':
        return (
          <FileUpload
            onFileAnalyzed={handleFileAnalyzed}
            maxFiles={5}
          />
        );
      case 'reports':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">My Reports</h2>
            <p className="text-muted-foreground">View and manage your uploaded medical reports</p>
            {/* In a real implementation, this would show a list of user's reports */}
          </div>
        );
      case 'timeline':
        return <HealthTimeline />;
      case 'chat':
        return (
          <div className="max-w-4xl mx-auto">
            <ChatInterface
              currentUserId={user.uid}
              currentChatRoom={mockChatRoom}
              onSendMessage={handleSendMessage}
              onCallDoctor={handleCallDoctor}
            />
          </div>
        );
      case 'reminders':
        return <Reminders userId={user.uid} />;
      case 'settings':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Settings</h2>
            <p className="text-muted-foreground">Manage your account and preferences</p>
            <div className="bg-card p-6 rounded-lg border">
              <h3 className="text-lg font-semibold mb-2">Account Information</h3>
              <p><strong>Email:</strong> {user.email}</p>
              <p><strong>Display Name:</strong> {user.displayName || 'Not set'}</p>
              <p><strong>Account Created:</strong> {user.metadata.creationTime}</p>
            </div>
          </div>
        );
      default:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Page Not Found</h2>
            <p className="text-muted-foreground">The requested page could not be found</p>
          </div>
        );
    }
  };

  return (
    <MainLayout
      currentUser={{
        name: user.displayName || user.email || 'User',
        email: user.email || '',
        avatar: user.photoURL || undefined
      }}
      onNavigate={handleNavigate}
      onLogout={handleLogout}
      currentPage={currentPage}
    >
      {renderPageContent()}
    </MainLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;